(() => {
  // src/shared.js
  function postIdentity(input) {
    const url = new URL(input);
    return url.searchParams.get("story_fbid") || url.searchParams.get("fbid") || url.pathname.match(/\/(?:posts|permalink|videos|reel)\/([^/]+)/)?.[1] || "";
  }

  // src/extract.js
  var ARTICLE = '[role="article"], article';
  var COMMENT_LABEL = /^(?:comment(?: by|o di|aire de)|kommentar von|comentario de|reply by|risposta di|r[eé]ponse de)\b/i;
  var REPLY_LABEL = /^(?:reply by|risposta di|r[eé]ponse de)\b/i;
  var UI_TEXT = /^(?:mi piace|like|reply|rispondi|condividi|share|modificato|edited|mostra altro|altro|see more|visualizza traduzione|see translation|\d+)$/i;
  function ownElements(article, selector) {
    return [...article.querySelectorAll(selector)].filter((node) => node.closest(ARTICLE) === article);
  }
  function linkUrl(link) {
    try {
      return new URL(link.getAttribute("href"), "https://www.facebook.com");
    } catch {
      return null;
    }
  }
  function commentLinks(article) {
    return ownElements(article, "a[href]").filter((link) => {
      const url = linkUrl(link);
      return url && (url.searchParams.has("comment_id") || url.searchParams.has("reply_comment_id"));
    });
  }
  function isCommentArticle(article) {
    return COMMENT_LABEL.test(article.getAttribute("aria-label") || "") || commentLinks(article).length > 0;
  }
  function isReply(article) {
    if (REPLY_LABEL.test(article.getAttribute("aria-label") || "")) return true;
    if (Number(article.getAttribute("aria-level") || 1) > 1) return true;
    for (let parent = article.parentElement?.closest(ARTICLE); parent; parent = parent.parentElement?.closest(ARTICLE)) {
      if (isCommentArticle(parent)) return true;
    }
    return commentLinks(article).some((link) => {
      const url = linkUrl(link);
      return url.searchParams.has("reply_comment_id") || url.searchParams.has("parent_comment_id");
    });
  }
  function readableText(node) {
    function walk(el) {
      if (el.nodeType === 3) return el.nodeValue;
      if (el.nodeType !== 1 || el.matches('script, style, button, [role="button"], [hidden], [aria-hidden="true"]')) return "";
      if (el.tagName === "IMG") return el.getAttribute("alt") || "";
      if (el.tagName === "BR") return "\n";
      const text = [...el.childNodes].map(walk).join("");
      return /^(DIV|P|LI)$/.test(el.tagName) ? text + "\n" : text;
    }
    return walk(node).replace(/\u00a0/g, " ").replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  }
  function authorLink(article) {
    const anchors = ownElements(article, "a[href]");
    return anchors.find((link) => {
      const url = linkUrl(link);
      if (!url || !/(^|\.)facebook\.com$/.test(url.hostname)) return false;
      if (url.searchParams.has("comment_id") || url.searchParams.has("reply_comment_id")) return false;
      const path = url.pathname;
      const profile = path === "/profile.php" || /^\/people\/[^/]+\/[^/]+/.test(path) || /\/user\/[^/]+/.test(path) || /^\/[^/]+\/?$/.test(path) && !/\.php$/.test(path);
      const reserved = /^\/(?:photo|watch|reel|share|login|help|stories|groups|hashtag|notifications|friends|home|marketplace)\/?$/;
      const text = readableText(link);
      return profile && !reserved.test(path) && text && !UI_TEXT.test(text);
    });
  }
  function timestamp(article) {
    const exact = ownElements(article, "time[datetime], abbr[data-utime]")[0];
    if (exact) {
      const raw = exact.getAttribute("datetime") || Number(exact.getAttribute("data-utime")) * 1e3;
      const date = new Date(raw);
      if (!Number.isNaN(date.getTime())) return date.toISOString();
    }
    const link = commentLinks(article)[0];
    if (link) {
      const titled = link.hasAttribute("title") ? link : link.querySelector("[title]");
      const title = titled?.getAttribute("title");
      if (title) return title.trim();
      const label = link.getAttribute("aria-label");
      if (label && !/^(?:like|mi piace|reply|rispondi|comment|commento)\b/i.test(label)) return label.trim();
      const text = (link.textContent || "").trim();
      if (text) return text;
    }
    const abbr = ownElements(article, "abbr[title], time")[0];
    return abbr?.getAttribute("title") || abbr?.textContent?.trim() || "";
  }
  function bodyText(article, author) {
    const explicit = ownElements(article, '[data-ad-preview="message"], [data-testid="comment_message"]');
    let candidates = explicit.length ? explicit : ownElements(article, '[dir="auto"]');
    candidates = candidates.filter((node) => {
      if (node === author || node.contains(author) || node.closest('a, button, [role="button"]')) return false;
      if (node.querySelector(`${ARTICLE}, a[href*="comment_id="], time, abbr[data-utime]`)) return false;
      return true;
    });
    candidates = candidates.filter((node) => !candidates.some((other) => other !== node && other.contains(node)));
    const body = candidates.map(readableText).filter(Boolean).join("\n");
    if (body) return body;
    const media = ownElements(article, "img").filter((img) => !img.closest("a") && !img.closest('button, [role="button"]'));
    return media.map((img) => `[Immagine: ${img.getAttribute("alt") || "senza descrizione"}]`).join("\n");
  }
  function extractComments(root) {
    const rows = [];
    for (const article of root.querySelectorAll(ARTICLE)) {
      if (!isCommentArticle(article) || isReply(article)) continue;
      const author = authorLink(article);
      const username = author ? readableText(author) : "";
      if (!username) continue;
      const text = bodyText(article, author);
      const time = timestamp(article);
      const link = commentLinks(article)[0];
      const id = link && linkUrl(link).searchParams.get("comment_id");
      rows.push({ key: id ? `id:${id}` : `fallback:${username}\0${text}\0${time}`, username, text, timestamp: time });
    }
    return rows;
  }
  function findPostScope(document2, postUrl) {
    const id = postIdentity(postUrl);
    const matchesPost = (node) => [...node.querySelectorAll("a[href]")].some((link) => {
      try {
        return postIdentity(new URL(link.getAttribute("href"), postUrl).href) === id;
      } catch {
        return false;
      }
    });
    const dialogs = [...document2.querySelectorAll('[role="dialog"]')].filter((el) => !el.hidden && el.getAttribute("aria-hidden") !== "true");
    const matchingDialog = dialogs.find(matchesPost);
    if (matchingDialog) return matchingDialog;
    const commentDialogs = dialogs.filter((el) => [...el.querySelectorAll(ARTICLE)].some(isCommentArticle));
    if (commentDialogs.length === 1) return commentDialogs[0];
    const main = document2.querySelector('[role="main"], main');
    if (!main) return null;
    const posts = [...main.querySelectorAll(ARTICLE)].filter((el) => !isCommentArticle(el) && !el.parentElement?.closest(ARTICLE));
    const matched = posts.find(matchesPost);
    if (matched) return matched;
    if (posts.length === 1) return posts[0];
    if (posts.length > 1) throw new Error("Sono presenti pi\xF9 post e non riesco a identificare quello richiesto. Apri il permalink del singolo post e riprova.");
    return main;
  }
  function isLoadMoreLabel(label) {
    const text = label.replace(/\s+/g, " ").trim();
    if (/rispost|repl|r[eé]pons/i.test(text)) return false;
    return /^(?:(?:visualizza|vedi|mostra|carica) (?:altri? |pi[uù] |i |\d+ )*(?:commenti)(?: precedenti)?|(?:view|see|load) (?:\d+ )?(?:more|previous) comments)$/i.test(text);
  }
  function expandableCommentButtons(root) {
    return [...root.querySelectorAll('button, [role="button"]')].filter((node) => {
      const article = node.closest(ARTICLE);
      return article && isCommentArticle(article) && !isReply(article) && !!node.closest('[dir="auto"], [data-ad-preview="message"], [data-testid="comment_message"]') && /^(?:mostra altro|altro|see more|visualizza altro)$/i.test(node.textContent.trim());
    });
  }

  // src/collector.js
  if (!globalThis.__facebookExcelCollector) {
    let scrollComments = function(scope) {
      const comments = scope.querySelectorAll('[role="article"], article');
      const last = comments[comments.length - 1];
      if (last) last.scrollIntoView({ block: "end", behavior: "instant" });
      let target = last?.parentElement || scope;
      while (target && target !== document.body) {
        if (target.scrollHeight > target.clientHeight + 30 && /auto|scroll/.test(getComputedStyle(target).overflowY)) {
          target.scrollTop = target.scrollHeight;
          return;
        }
        target = target.parentElement;
      }
      if (scope.matches('[role="main"], main') || !scope.closest('[role="dialog"]')) window.scrollBy(0, 650);
    };
    globalThis.__facebookExcelCollector = true;
    let running = false;
    let stopRequested = false;
    const pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    const send = (message) => chrome.runtime.sendMessage(message).catch(() => {
    });
    const visible = (el) => !!el.getClientRects().length && getComputedStyle(el).visibility !== "hidden";
    const allLabel = /^(?:tutti i commenti|all comments)(?:\b|$)/i;
    const filterLabel = /^(?:pi[uù] (?:pertinenti|rilevanti|recenti)|most relevant|newest|tutti i commenti|all comments)$/i;
    async function chooseAll(scope) {
      const filter = [...scope.querySelectorAll('button, [role="button"]')].find((el) => visible(el) && filterLabel.test(el.textContent.trim()));
      if (!filter) return false;
      if (allLabel.test(filter.textContent.trim())) return true;
      filter.click();
      await pause(450);
      const option = [...document.querySelectorAll('[role="menuitem"], [role="menuitemradio"], [role="option"]')].find((el) => visible(el) && allLabel.test(el.textContent.trim()));
      if (!option) {
        filter.click();
        return false;
      }
      option.click();
      await pause(900);
      return true;
    }
    async function collect({ runId, url }) {
      if (running) throw new Error("Una raccolta \xE8 gi\xE0 attiva in questa scheda.");
      running = true;
      stopRequested = false;
      const rows = /* @__PURE__ */ new Map();
      const started = Date.now();
      let allSelected = false;
      let idle = 0;
      let passes = 0;
      let reason = "Nessun altro commento principale caricabile rilevato.";
      try {
        await pause(1500);
        while (!stopRequested && Date.now() - started < 9e5) {
          const scope = findPostScope(document, url);
          if (!scope) {
            if (++passes > 12) throw new Error("Post non disponibile. Verifica di essere connesso a Facebook e che il link sia accessibile.");
            await pause(1e3);
            continue;
          }
          if (!allSelected && passes % 8 === 0) allSelected = await chooseAll(scope);
          const count = rows.size;
          let changed = false;
          for (const row of extractComments(scope)) {
            const before = rows.get(row.key);
            if (before && (before.text !== row.text || before.timestamp !== row.timestamp)) changed = true;
            rows.set(row.key, row);
          }
          for (const button of expandableCommentButtons(scope).filter(visible).slice(0, 5)) button.click();
          const more = [...scope.querySelectorAll('button, [role="button"]')].find((el) => visible(el) && isLoadMoreLabel(el.textContent));
          if (more) more.click();
          scrollComments(scope);
          idle = rows.size === count && !changed ? idle + 1 : 0;
          await send({
            type: "PROGRESS",
            runId,
            count: rows.size,
            allSelected,
            message: more ? "Caricamento di altri commenti principali\u2026" : "Lettura dei commenti principali\u2026"
          });
          if (idle >= 8) {
            if (more) reason = "Caricamento fermo: il pulsante per altri commenti non produce nuovi risultati.";
            break;
          }
          passes++;
          await pause(1200);
        }
        if (stopRequested) reason = "Raccolta interrotta manualmente: esportazione parziale.";
        else if (Date.now() - started >= 9e5) reason = "Raggiunto il limite di 15 minuti: esportazione potenzialmente parziale.";
        const finalScope = findPostScope(document, url);
        if (finalScope) for (const row of extractComments(finalScope)) rows.set(row.key, row);
        if (!rows.size) throw new Error("Nessun commento principale riconosciuto. Verifica accesso, presenza di commenti e filtro \xABTutti i commenti\xBB. Facebook potrebbe aver modificato la pagina.");
        await send({ type: "COMPLETE", runId, rows: [...rows.values()], allSelected, reason });
      } catch (error) {
        await send({ type: "FAILED", runId, error: error.message });
      } finally {
        running = false;
      }
    }
    chrome.runtime.onMessage.addListener((message, sender, reply) => {
      if (message.type === "COLLECT") {
        if (running) {
          reply({ ok: false, error: "Raccolta gi\xE0 in corso." });
          return;
        }
        void collect(message);
        reply({ ok: true });
      } else if (message.type === "STOP_COLLECTING") {
        stopRequested = true;
        reply({ ok: true });
      }
    });
  }
})();
