// src/shared.js
var STATE_KEY = "exportState";
var ACTIVE_STATUSES = ["opening", "collecting", "exporting"];
function parsePostUrl(input) {
  let url;
  try {
    url = new URL(input.trim());
  } catch {
    throw new Error("Inserisci un link Facebook valido.");
  }
  if (!["facebook.com", "www.facebook.com", "m.facebook.com", "mbasic.facebook.com", "web.facebook.com"].includes(url.hostname) || !["https:", "http:"].includes(url.protocol) || url.username || url.password || url.port) {
    throw new Error("Usa un link diretto a un post su facebook.com.");
  }
  const pathPost = /\/(?:posts|permalink|videos|reel)\/[^/]+/.test(url.pathname);
  const queryPost = /\/(?:story|permalink|photo)\.php$/.test(url.pathname) && (url.searchParams.has("story_fbid") || url.searchParams.has("fbid"));
  const photo = /^\/photo\/?$/.test(url.pathname) && url.searchParams.has("fbid");
  if (!pathPost && !queryPost && !photo) {
    throw new Error("Serve il permalink del post: apri il post e copia il link dalla data. I link brevi /share/ non sono supportati.");
  }
  url.protocol = "https:";
  url.hostname = "www.facebook.com";
  url.hash = "";
  for (const name of [...url.searchParams.keys()]) {
    if (!["id", "story_fbid", "fbid", "set"].includes(name)) url.searchParams.delete(name);
  }
  return url.href;
}

// src/popup.js
var $ = (id) => document.getElementById(id);
var current;
function render(state) {
  current = state;
  const active = ACTIVE_STATUSES.includes(state?.status);
  $("start").disabled = active;
  $("url").disabled = active;
  $("status-panel").hidden = !state;
  if (!state) return;
  if (!$("url").value && state.url) $("url").value = state.url;
  $("status-label").textContent = { opening: "Apertura del post", collecting: "Raccolta in corso", exporting: "Creazione Excel", done: "File Excel scaricato", error: "Operazione interrotta" }[state.status] || state.status;
  $("count").textContent = (state.count || 0).toLocaleString("it-IT");
  $("message").textContent = state.message || "";
  $("warning").textContent = state.warning || "";
  $("warning").hidden = !state.warning;
  $("stop").hidden = !["opening", "collecting"].includes(state.status);
  $("stop").textContent = state.status === "opening" ? "Annulla apertura" : "Ferma e scarica i commenti raccolti";
  $("focus").hidden = !active || !state.tabId;
}
async function request(message) {
  const reply = await chrome.runtime.sendMessage(message);
  if (!reply?.ok) throw new Error(reply?.error || "Estensione non disponibile. Riprova.");
  return reply;
}
$("form").addEventListener("submit", async (event) => {
  event.preventDefault();
  $("start").disabled = true;
  try {
    const url = parsePostUrl($("url").value);
    await request({ type: "START", url });
    render((await chrome.storage.session.get(STATE_KEY))[STATE_KEY]);
  } catch (error) {
    render({ status: "error", message: error.message, count: 0 });
  }
});
$("stop").addEventListener("click", async () => {
  $("stop").disabled = true;
  try {
    await request({ type: "STOP" });
  } catch (error) {
    $("message").textContent = error.message;
  } finally {
    $("stop").disabled = false;
  }
});
$("focus").addEventListener("click", async () => {
  try {
    await chrome.tabs.update(current.tabId, { active: true });
  } catch {
    $("message").textContent = "La scheda Facebook \xE8 stata chiusa.";
  }
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "session" && changes[STATE_KEY]) render(changes[STATE_KEY].newValue);
});
render((await chrome.storage.session.get(STATE_KEY))[STATE_KEY]);
