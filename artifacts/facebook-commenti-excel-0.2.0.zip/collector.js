(() => {
  // src/shared.js
  function postIdentity(input) {
    const url = new URL(input);
    return url.searchParams.get("story_fbid") || url.searchParams.get("fbid") || url.searchParams.get("v") || url.pathname.match(/\/(?:posts|permalink|videos|reel)\/([^/]+)/)?.[1] || "";
  }

  // src/page-controls.js
  function isCommentsOpener(label) {
    const text = label.replace(/\s+/g, " ").trim();
    return /^(?:(?:show|view|see|open|mostra|visualizza|vedi|apri) )?(?:(?:[\d.,]+\s*[kKmM]?|all|tutti i) )?(?:comments|commenti)(?:\s*\(?[\d.,]+\s*[kKmM]?\)?)?$/i.test(text);
  }
  function findCommentsOpener(scope, visible = () => true) {
    return [...scope.querySelectorAll('button, [role="button"], a[role="link"]')].find((node) => {
      if (!visible(node) || node.getAttribute("aria-expanded") === "true") return false;
      return [node.getAttribute("aria-label"), node.getAttribute("title"), node.textContent].filter(Boolean).some(isCommentsOpener);
    });
  }
  function findSortControl(scope, visible = () => true) {
    return [...scope.querySelectorAll('button, [role="button"]')].find((node) => visible(node) && /^(?:pi[uù] (?:pertinenti|rilevanti|recenti)|most relevant|newest|tutti i commenti|all comments)$/i.test((node.getAttribute("aria-label") || node.textContent).replace(/\s+/g, " ").trim()));
  }

  // src/extract.js
  var ARTICLE = '[role="article"], article';
  var ROOT_HINT = '[data-testid^="UFI2Comment/root"], [data-comment-id], [data-commentid], [role="listitem"]';
  var COMMENT_LABEL = /^(?:comment(?: by|o di|aire de)|kommentar von|comentario de|reply by|risposta di|r[eé]ponse de)\b/i;
  var REPLY_LABEL = /^(?:reply by|risposta di|r[eé]ponse de)\b/i;
  var UI_TEXT = /^(?:mi piace|like|reply|rispondi|condividi|share|modificato|edited|mostra altro|altro|see more|visualizza traduzione|see translation|\d+)$/i;
  function ownElements(article, selector, boundaries = /* @__PURE__ */ new Set()) {
    return [...article.querySelectorAll(selector)].filter((node) => {
      for (let parent = node.parentElement; parent && parent !== article; parent = parent.parentElement) {
        if (parent.matches(`${ARTICLE}, ${ROOT_HINT}`) || boundaries.has(parent)) return false;
      }
      return true;
    });
  }
  function linkUrl(link) {
    try {
      return new URL(link.getAttribute("href"), link.ownerDocument.URL === "about:blank" ? "https://www.facebook.com" : link.ownerDocument.URL);
    } catch {
      return null;
    }
  }
  function commentLinks(article, boundaries) {
    return ownElements(article, "a[href]", boundaries).filter((link) => {
      const url = linkUrl(link);
      return url && url.pathname !== "/profile.php" && (url.searchParams.has("comment_id") || url.searchParams.has("reply_comment_id"));
    });
  }
  function isCommentArticle(article) {
    return COMMENT_LABEL.test(article.getAttribute("aria-label") || "") || commentLinks(article).length > 0;
  }
  function isReply(article, boundaries) {
    if (REPLY_LABEL.test(article.getAttribute("aria-label") || "")) return true;
    if (Number(article.getAttribute("aria-level") || 1) > 1) return true;
    for (let parent = article.parentElement; parent; parent = parent.parentElement) {
      if (boundaries ? boundaries.has(parent) : parent.matches(ARTICLE) && isCommentArticle(parent)) return true;
    }
    return commentLinks(article, boundaries).some((link) => {
      const url = linkUrl(link);
      return url.searchParams.has("reply_comment_id") || url.searchParams.has("parent_comment_id");
    });
  }
  function readableText(node) {
    function walk(el) {
      if (el.nodeType === 3) return el.nodeValue;
      if (el.nodeType !== 1 || el.matches('script, style, button, [role="button"], [hidden], [aria-hidden="true"]')) return "";
      if (el.tagName === "IMG") return el.getAttribute("alt") || "";
      if (el.tagName === "BR") return "\n";
      const text = [...el.childNodes].map(walk).join("");
      return /^(DIV|P|LI)$/.test(el.tagName) ? text + "\n" : text;
    }
    return walk(node).replace(/\u00a0/g, " ").replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  }
  function authorLink(article, boundaries) {
    const anchors = ownElements(article, "a[href]", boundaries);
    return anchors.find((link) => {
      const url = linkUrl(link);
      if (!url || !/(^|\.)facebook\.com$/.test(url.hostname)) return false;
      const path = url.pathname;
      const profile = path === "/profile.php" || /^\/people\/[^/]+\/[^/]+/.test(path) || /\/user\/[^/]+/.test(path) || /^\/[^/]+\/?$/.test(path) && !/\.php$/.test(path);
      const reserved = /^\/(?:photo|watch|reel|share|login|help|stories|groups|hashtag|notifications|friends|home|marketplace)\/?$/;
      const text = readableText(link);
      return profile && !reserved.test(path) && text && !UI_TEXT.test(text);
    });
  }
  function timestamp(article, boundaries) {
    const exact = ownElements(article, "time[datetime], [data-utime]", boundaries)[0];
    if (exact) {
      const raw = exact.getAttribute("datetime") || Number(exact.getAttribute("data-utime")) * 1e3;
      const date = new Date(raw);
      if (!Number.isNaN(date.getTime())) return date.toISOString();
    }
    const link = commentLinks(article, boundaries)[0];
    if (link) {
      const titled = link.hasAttribute("title") ? link : link.querySelector("[title]");
      const title = titled?.getAttribute("title");
      if (title) return title.trim();
      const label = link.getAttribute("aria-label");
      if (label && !/^(?:like|mi piace|reply|rispondi|comment|commento)\b/i.test(label)) return label.trim();
      const text = (link.textContent || "").trim();
      if (text) return text;
    }
    const abbr = ownElements(article, "abbr[title], time", boundaries)[0];
    if (abbr) return abbr.getAttribute("title") || abbr.textContent.trim();
    const relative = ownElements(article, 'a, [role="link"]', boundaries).find((node) => /^\d+\s*(?:s|sec|min|m|h|d|g|w|wk|sett|y|a)(?:\b|$)/i.test(node.textContent.trim()));
    return relative?.getAttribute("title") || relative?.textContent.trim() || "";
  }
  function bodyText(article, author, boundaries) {
    const explicit = ownElements(article, '[data-ad-preview="message"], [data-testid="comment_message"]', boundaries);
    let candidates = explicit.length ? explicit : ownElements(article, '[dir="auto"], [dir="ltr"], [dir="rtl"]', boundaries);
    candidates = candidates.filter((node) => {
      if (node === author || node.contains(author) || node.closest('a, button, [role="button"]')) return false;
      if (node.querySelector(`${ARTICLE}, a[href*="comment_id="], time, abbr[data-utime]`)) return false;
      return true;
    });
    candidates = candidates.filter((node) => !candidates.some((other) => other !== node && other.contains(node)));
    const body = candidates.map(readableText).filter(Boolean).join("\n");
    if (body) return body;
    const media = ownElements(article, "img", boundaries).filter((img) => !img.closest("a") && !img.closest('button, [role="button"]'));
    return media.map((img) => `[Immagine: ${img.getAttribute("alt") || "senza descrizione"}]`).join("\n");
  }
  function includeRoot(root, selector) {
    return [...root.matches?.(selector) ? [root] : [], ...root.querySelectorAll(selector)];
  }
  function commentToken(link) {
    const url = linkUrl(link);
    return url && (url.searchParams.get("reply_comment_id") || url.searchParams.get("comment_id"));
  }
  function hidden(node) {
    for (let parent = node; parent; parent = parent.parentElement) {
      if (parent.hidden || parent.getAttribute("aria-hidden") === "true" || parent.style.display === "none") return true;
    }
    return false;
  }
  function commentContainers(root) {
    const candidates = new Set(includeRoot(root, `${ARTICLE}, ${ROOT_HINT}`).filter((node) => !hidden(node) && isCommentArticle(node)));
    for (const link of root.querySelectorAll('a[href*="comment_id="]')) {
      if (hidden(link) || !commentToken(link) || linkUrl(link)?.pathname === "/profile.php") continue;
      let covered = false;
      for (let parent = link.parentElement; parent; parent = parent.parentElement) {
        if (candidates.has(parent) && COMMENT_LABEL.test(parent.getAttribute("aria-label") || "") && authorLink(parent)) {
          covered = true;
          break;
        }
        if (parent === root) break;
      }
      if (covered) continue;
      let node = link.parentElement;
      for (let depth = 0; node && depth < 9 && (node === root || root.contains(node)); depth++, node = node.parentElement) {
        const tokens = new Set(commentLinks(node).map(commentToken).filter(Boolean));
        if (tokens.size > 1) break;
        const author = authorLink(node);
        if (tokens.size === 1 && author && bodyText(node, author)) {
          candidates.add(node);
          break;
        }
        if (node === root) break;
      }
    }
    const candidateLinks = new Map([...candidates].map((node) => [node, commentLinks(node)]));
    const byToken = /* @__PURE__ */ new Map();
    for (const [node, links] of candidateLinks) {
      const token = commentToken(links[0]);
      if (token) {
        if (!byToken.has(token)) byToken.set(token, []);
        byToken.get(token).push(node);
      }
    }
    const result = [...candidates].filter((node) => {
      const links = candidateLinks.get(node);
      if (!COMMENT_LABEL.test(node.getAttribute("aria-label") || "") && new Set(links.map(commentToken)).size > 1) return false;
      return !(byToken.get(commentToken(links[0])) || []).some((other) => {
        if (other === node) return false;
        if (node.contains(other) && !COMMENT_LABEL.test(node.getAttribute("aria-label") || "")) return true;
        return other.contains(node) && COMMENT_LABEL.test(other.getAttribute("aria-label") || "");
      });
    });
    return result.sort((a, b) => a.compareDocumentPosition(b) & 4 ? -1 : 1);
  }
  function extractComments(root, postUrl) {
    const rows = [];
    const containers = commentContainers(root);
    const boundaries = new Set(containers);
    const target = postUrl ? postIdentity(postUrl) : "";
    for (const article of containers) {
      if (isReply(article, boundaries)) continue;
      const links = commentLinks(article, boundaries);
      const linkedPost = links.map((link2) => postIdentity(linkUrl(link2).href)).filter(Boolean);
      if (target && linkedPost.length && !linkedPost.includes(target)) continue;
      const author = authorLink(article, boundaries);
      const username = author ? readableText(author) : "";
      if (!username) continue;
      const text = bodyText(article, author, boundaries);
      const time = timestamp(article, boundaries);
      const link = links[0];
      const id = link && linkUrl(link).searchParams.get("comment_id");
      rows.push({ key: id ? `id:${id}` : `fallback:${username}\0${text}\0${time}`, username, text, timestamp: time });
    }
    return rows;
  }
  function findPostScope(document2, postUrl) {
    const id = postIdentity(postUrl);
    const matchesPost = (node) => id && [...node.querySelectorAll("a[href]")].some((link) => {
      try {
        return postIdentity(new URL(link.getAttribute("href"), postUrl).href) === id;
      } catch {
        return false;
      }
    });
    const dialogs = [...document2.querySelectorAll('[role="dialog"]')].filter((el) => !el.hidden && el.getAttribute("aria-hidden") !== "true");
    const matchingDialog = dialogs.find(matchesPost);
    if (matchingDialog) return matchingDialog;
    const videoDialog = dialogs.find((node) => node.querySelector("video") && findCommentsOpener(node));
    if (videoDialog) return videoDialog;
    const commentDialogs = dialogs.filter((el) => [...el.querySelectorAll(ARTICLE)].some(isCommentArticle));
    if (commentDialogs.length === 1) return commentDialogs[0];
    const roots = commentContainers(document2);
    const targetRoots = roots.filter((node) => commentLinks(node).some((link) => postIdentity(linkUrl(link).href) === id));
    const panels = [...document2.querySelectorAll('aside, section, [role="complementary"], [role="region"]')].filter((panel2) => !panel2.hidden && panel2.getAttribute("aria-hidden") !== "true" && /^(?:comments|commenti)(?:\b|$)/i.test(panel2.getAttribute("aria-label") || ""));
    const panel = panels.find((node) => targetRoots.some((row) => node.contains(row))) || (panels.length === 1 && postIdentity(document2.URL) === id ? panels[0] : null);
    if (panel) return panel;
    const main = document2.querySelector('[role="main"], main');
    if (!main) {
      const external = targetRoots[0]?.closest('[role="dialog"], aside, [role="complementary"], section');
      if (external) return external;
      if (postIdentity(document2.URL) === id && document2.querySelector("video") && findCommentsOpener(document2.body)) return document2.body;
      return null;
    }
    const posts = [...main.querySelectorAll(ARTICLE)].filter((el) => !isCommentArticle(el) && !el.parentElement?.closest(ARTICLE));
    const matched = posts.find(matchesPost);
    if (matched) {
      if (targetRoots.some((row) => !matched.contains(row))) {
        const external = targetRoots.find((row) => !main.contains(row));
        return external?.closest('aside, section, [role="complementary"]') || (external ? external.parentElement : main);
      }
      return matched;
    }
    if (posts.length === 1) return posts[0];
    if (posts.length > 1) throw new Error("Sono presenti pi\xF9 post e non riesco a identificare quello richiesto. Apri il permalink del singolo post e riprova.");
    return main;
  }
  function isLoadMoreLabel(label) {
    const text = label.replace(/\s+/g, " ").trim();
    if (/rispost|repl|r[eé]pons/i.test(text)) return false;
    return /^(?:(?:visualizza|vedi|mostra|carica) (?:altri? |pi[uù] |i |\d+ )*(?:commenti)(?: precedenti)?|(?:view|see|load) (?:\d+ )?(?:more|previous) comments)$/i.test(text);
  }
  function expandableCommentButtons(root) {
    const containers = commentContainers(root);
    const boundaries = new Set(containers);
    return [...root.querySelectorAll('button, [role="button"]')].filter((node) => {
      let article = node.parentElement;
      while (article && !boundaries.has(article)) article = article.parentElement;
      return article && !isReply(article, boundaries) && !!node.closest('[dir="auto"], [data-ad-preview="message"], [data-testid="comment_message"]') && /^(?:mostra altro|altro|see more|visualizza altro)$/i.test(node.textContent.trim());
    });
  }
  function layoutDiagnostics(document2, scope) {
    const candidates = commentContainers(scope || document2);
    return {
      schema: 1,
      pageKind: /\/watch\b/.test(document2.location.pathname) ? "watch" : /\/videos\//.test(document2.location.pathname) ? "video" : "post",
      roleArticles: document2.querySelectorAll(ARTICLE).length,
      commentPermalinks: document2.querySelectorAll('a[href*="comment_id="]').length,
      candidates: candidates.length,
      withAuthor: candidates.filter((node) => authorLink(node)).length,
      recognizedRows: extractComments(scope || document2).length,
      scope: scope ? { tag: scope.tagName, role: scope.getAttribute("role") || "" } : null,
      frames: document2.querySelectorAll("iframe").length,
      // Counts/structural flags only: no names, comments, URLs, cookies or HTML.
      samples: candidates.slice(0, 3).map((node) => ({
        tag: node.tagName,
        role: node.getAttribute("role") || "",
        hasCommentLabel: COMMENT_LABEL.test(node.getAttribute("aria-label") || ""),
        messageBlocks: ownElements(node, '[dir], [data-ad-preview="message"]').length,
        commentLinks: commentLinks(node).length
      }))
    };
  }

  // src/collector.js
  if (!globalThis.__facebookExcelCollector) {
    let scrollComments = function(scope) {
      const comments = commentContainers(scope);
      const last = comments[comments.length - 1];
      if (last) last.scrollIntoView({ block: "end", behavior: "instant" });
      let target = last?.parentElement || scope;
      while (target && target !== document.body) {
        if (target.scrollHeight > target.clientHeight + 30 && /auto|scroll/.test(getComputedStyle(target).overflowY)) {
          target.scrollTop = target.scrollHeight;
          return;
        }
        target = target.parentElement;
      }
      if (scope.matches('[role="main"], main') || !scope.closest('[role="dialog"]')) window.scrollBy(0, 650);
    };
    globalThis.__facebookExcelCollector = true;
    let running = false;
    let stopRequested = false;
    const pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    const send = (message) => chrome.runtime.sendMessage(message).catch(() => {
    });
    const visible = (el) => !!el.getClientRects().length && getComputedStyle(el).visibility !== "hidden";
    const allLabel = /^(?:tutti i commenti|all comments)(?:\b|$)/i;
    async function chooseAll(scope) {
      const filter = findSortControl(scope, visible);
      if (!filter) return false;
      if (allLabel.test(filter.getAttribute("aria-label") || filter.textContent.trim())) return true;
      filter.click();
      await pause(450);
      const option = [...document.querySelectorAll('[role="menuitem"], [role="menuitemradio"], [role="option"]')].find((el) => visible(el) && allLabel.test(el.textContent.trim()));
      if (!option) {
        filter.click();
        return false;
      }
      option.click();
      await pause(900);
      return true;
    }
    async function collect({ runId, url }) {
      if (running) throw new Error("Una raccolta \xE8 gi\xE0 attiva in questa scheda.");
      running = true;
      stopRequested = false;
      const rows = /* @__PURE__ */ new Map();
      const started = Date.now();
      let allSelected = false;
      let idle = 0;
      let passes = 0;
      let clickedOpener = false;
      let lastScope = null;
      let reason = "Nessun altro commento principale caricabile rilevato.";
      try {
        await pause(1500);
        while (!stopRequested && Date.now() - started < 9e5) {
          let scope = findPostScope(document, url);
          lastScope = scope;
          if (!scope) {
            if (++passes > 12) throw new Error("Post non disponibile. Verifica di essere connesso a Facebook e che il link sia accessibile.");
            await pause(1e3);
            continue;
          }
          if (!clickedOpener && !commentContainers(scope).length && !findSortControl(scope, visible)) {
            const opener = findCommentsOpener(scope, visible);
            if (opener) {
              clickedOpener = true;
              await send({ type: "PROGRESS", runId, count: rows.size, allSelected, message: "Apertura del pannello commenti del video\u2026" });
              opener.click();
              await pause(1500);
              scope = findPostScope(document, url) || scope;
              lastScope = scope;
            }
          }
          if (!allSelected && passes % 8 === 0) allSelected = await chooseAll(scope);
          const count = rows.size;
          let changed = false;
          for (const row of extractComments(scope, url)) {
            const before = rows.get(row.key);
            if (before && (before.text !== row.text || before.timestamp !== row.timestamp)) changed = true;
            rows.set(row.key, row);
          }
          for (const button of expandableCommentButtons(scope).filter(visible).slice(0, 5)) button.click();
          const more = [...scope.querySelectorAll('button, [role="button"]')].find((el) => visible(el) && isLoadMoreLabel(el.textContent));
          if (more) more.click();
          scrollComments(scope);
          idle = rows.size === count && !changed ? idle + 1 : 0;
          await send({
            type: "PROGRESS",
            runId,
            count: rows.size,
            allSelected,
            message: !rows.size ? "Attendo i commenti. Se il pannello \xE8 chiuso, premi \xABComments\xBB nella scheda Facebook." : more ? "Caricamento di altri commenti principali\u2026" : "Lettura dei commenti principali\u2026"
          });
          if (idle >= (rows.size ? 8 : 24)) {
            if (more) reason = "Caricamento fermo: il pulsante per altri commenti non produce nuovi risultati.";
            break;
          }
          passes++;
          await pause(1200);
        }
        if (stopRequested) reason = "Raccolta interrotta manualmente: esportazione parziale.";
        else if (Date.now() - started >= 9e5) reason = "Raggiunto il limite di 15 minuti: esportazione potenzialmente parziale.";
        const finalScope = findPostScope(document, url);
        if (finalScope) for (const row of extractComments(finalScope, url)) rows.set(row.key, row);
        if (!rows.size) throw new Error("Non riesco a leggere i commenti di questa pagina. Apri \xABComments\xBB nella scheda Facebook e riprova. Se sono gi\xE0 visibili, mostrami la diagnostica dal popup.");
        await send({ type: "COMPLETE", runId, rows: [...rows.values()], allSelected, reason });
      } catch (error) {
        let diagnostics;
        try {
          diagnostics = { ...layoutDiagnostics(document, lastScope), openerClicked: clickedOpener };
        } catch {
          diagnostics = { schema: 1, diagnosticError: true };
        }
        await send({ type: "FAILED", runId, error: error.message, diagnostics });
      } finally {
        running = false;
      }
    }
    chrome.runtime.onMessage.addListener((message, sender, reply) => {
      if (message.type === "COLLECT") {
        if (running) {
          reply({ ok: false, error: "Raccolta gi\xE0 in corso." });
          return;
        }
        void collect(message);
        reply({ ok: true });
      } else if (message.type === "STOP_COLLECTING") {
        stopRequested = true;
        reply({ ok: true });
      }
    });
  }
})();
