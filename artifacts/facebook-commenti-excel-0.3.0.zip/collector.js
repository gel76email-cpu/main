(() => {
  // src/shared.js
  function parsePostUrl(input) {
    let url;
    try {
      url = new URL(input.trim());
    } catch {
      throw new Error("Inserisci un link Facebook valido.");
    }
    if (!["facebook.com", "www.facebook.com", "m.facebook.com", "mbasic.facebook.com", "web.facebook.com"].includes(url.hostname) || !["https:", "http:"].includes(url.protocol) || url.username || url.password || url.port) {
      throw new Error("Usa un link diretto a un post su facebook.com.");
    }
    const pathPost = /\/(?:posts|permalink|videos|reel)\/[^/]+/.test(url.pathname);
    const queryPost = /\/(?:story|permalink|photo)\.php$/.test(url.pathname) && (url.searchParams.has("story_fbid") || url.searchParams.has("fbid"));
    const photo = /^\/photo\/?$/.test(url.pathname) && url.searchParams.has("fbid");
    const watch = /^\/watch(?:\/live)?\/?$/.test(url.pathname) && /^\d+$/.test(url.searchParams.get("v") || "");
    if (!pathPost && !queryPost && !photo && !watch) {
      throw new Error("Serve il permalink del post: apri il post e copia il link dalla data. I link brevi /share/ non sono supportati.");
    }
    url.protocol = "https:";
    url.hostname = "www.facebook.com";
    url.hash = "";
    for (const name of [...url.searchParams.keys()]) {
      if (!["id", "story_fbid", "fbid", "set", "v"].includes(name)) url.searchParams.delete(name);
    }
    return url.href;
  }
  function postIdentity(input) {
    const url = new URL(input);
    return url.searchParams.get("story_fbid") || url.searchParams.get("fbid") || url.searchParams.get("v") || url.pathname.match(/\/(?:posts|permalink|videos|reel)\/([^/]+)/)?.[1] || "";
  }
  function samePost(input, expected) {
    try {
      return postIdentity(parsePostUrl(input)) === postIdentity(parsePostUrl(expected));
    } catch {
      return false;
    }
  }

  // src/page-controls.js
  function isCommentsOpener(label) {
    const text = label.replace(/\s+/g, " ").trim();
    return /^(?:(?:show|view|see|open|mostra|visualizza|vedi|apri) )?(?:(?:[\d.,]+\s*[kKmM]?|all|tutti i) )?(?:comments|commenti)(?:\s*\(?[\d.,]+\s*[kKmM]?\)?)?$/i.test(text);
  }
  function findCommentsOpener(scope, visible = () => true) {
    return [...scope.querySelectorAll('button, [role="button"], a[role="link"]')].find((node) => {
      if (!visible(node) || node.getAttribute("aria-expanded") === "true") return false;
      return [node.getAttribute("aria-label"), node.getAttribute("title"), node.textContent].filter(Boolean).some(isCommentsOpener);
    });
  }
  function controlBusy(node) {
    return !!(node?.disabled || node?.getAttribute("aria-disabled") === "true" || node?.getAttribute("aria-busy") === "true");
  }
  function sortChoice(node) {
    if (!node) return "unknown";
    const labels = [
      node.getAttribute("aria-label"),
      node.getAttribute("title"),
      node.innerText,
      node.textContent,
      ...[...node.querySelectorAll('span, [dir="auto"]')].slice(0, 12).map((child) => child.textContent)
    ];
    for (const label of labels.filter(Boolean)) {
      const text = label.replace(/[\u00a0\s]+/g, " ").replace(/[⌄▾▼]+$/g, "").trim();
      const prefix = "(?:(?:sort(?: comments)? by|sorted by|ordina(?: i commenti)? per|comment ranking|commenti|comments)\\s*:?\\s*)?";
      if (new RegExp(`^${prefix}(?:all comments|tutti i commenti)\\b`, "i").test(text)) return "all";
      if (new RegExp(`^${prefix}(?:most relevant|pi[u\xF9] (?:pertinenti|rilevanti))\\b`, "i").test(text)) return "relevant";
      if (new RegExp(`^${prefix}(?:newest|pi[u\xF9] recenti)\\b`, "i").test(text)) return "newest";
    }
    return "unknown";
  }
  function findSortControl(scope, visible = () => true) {
    if (!scope) return null;
    return [...scope.querySelectorAll('button, [role="button"], [aria-haspopup="menu"], a[role="link"]')].find((node) => visible(node) && !node.closest('[role="menu"], [role="listbox"], [role="menuitemradio"], [role="menuitem"], [role="option"]') && sortChoice(node) !== "unknown") || null;
  }
  async function selectAllComments(getScope, { document: document2, visible = () => true, pause, stopped = () => false }) {
    const control = findSortControl(getScope(), visible);
    if (!control) return false;
    if (sortChoice(control) === "all") return true;
    control.click();
    let option;
    for (let attempt = 0; attempt < 10 && !stopped(); attempt++) {
      await pause(200);
      option = [...document2.querySelectorAll('[role="menuitem"], [role="menuitemradio"], [role="option"], [role="menu"] button, [role="menu"] [role="button"], [role="listbox"] [role="button"]')].find((node) => visible(node) && sortChoice(node) === "all");
      if (option) break;
    }
    if (!option || stopped()) {
      if (control.isConnected && control.getAttribute("aria-expanded") === "true") control.click();
      return false;
    }
    option.click();
    for (let attempt = 0; attempt < 15 && !stopped(); attempt++) {
      await pause(200);
      if (sortChoice(findSortControl(getScope(), visible)) === "all") return true;
    }
    return false;
  }

  // src/extract.js
  var ARTICLE = '[role="article"], article';
  var ROOT_HINT = '[data-testid^="UFI2Comment/root"], [data-comment-id], [data-commentid], [role="listitem"]';
  var COMMENT_LABEL = /^(?:comment(?: by|o di|aire de)|kommentar von|comentario de|reply by|risposta di|r[eé]ponse de)\b/i;
  var REPLY_LABEL = /^(?:reply by|risposta di|r[eé]ponse de)\b/i;
  var UI_TEXT = /^(?:mi piace|like|reply|rispondi|condividi|share|modificato|edited|mostra altro|altro|see more|visualizza traduzione|see translation|\d+)$/i;
  function ownElements(article, selector, boundaries = /* @__PURE__ */ new Set()) {
    return [...article.querySelectorAll(selector)].filter((node) => {
      for (let parent = node.parentElement; parent && parent !== article; parent = parent.parentElement) {
        if (parent.matches(`${ARTICLE}, ${ROOT_HINT}`) || boundaries.has(parent)) return false;
      }
      return true;
    });
  }
  function linkUrl(link) {
    try {
      return new URL(link.getAttribute("href"), link.ownerDocument.URL === "about:blank" ? "https://www.facebook.com" : link.ownerDocument.URL);
    } catch {
      return null;
    }
  }
  function commentLinks(article, boundaries) {
    return ownElements(article, "a[href]", boundaries).filter((link) => {
      const url = linkUrl(link);
      return url && url.pathname !== "/profile.php" && (url.searchParams.has("comment_id") || url.searchParams.has("reply_comment_id"));
    });
  }
  function isCommentArticle(article) {
    return COMMENT_LABEL.test(article.getAttribute("aria-label") || "") || commentLinks(article).length > 0;
  }
  function isReply(article, boundaries) {
    if (REPLY_LABEL.test(article.getAttribute("aria-label") || "")) return true;
    if (Number(article.getAttribute("aria-level") || 1) > 1) return true;
    for (let parent = article.parentElement; parent; parent = parent.parentElement) {
      if (boundaries ? boundaries.has(parent) : parent.matches(ARTICLE) && isCommentArticle(parent)) return true;
    }
    return commentLinks(article, boundaries).some((link) => {
      const url = linkUrl(link);
      return url.searchParams.has("reply_comment_id") || url.searchParams.has("parent_comment_id");
    });
  }
  function readableText(node) {
    function walk(el) {
      if (el.nodeType === 3) return el.nodeValue;
      if (el.nodeType !== 1 || el.matches('script, style, button, [role="button"], [hidden], [aria-hidden="true"]')) return "";
      if (el.tagName === "IMG") return el.getAttribute("alt") || "";
      if (el.tagName === "BR") return "\n";
      const text = [...el.childNodes].map(walk).join("");
      return /^(DIV|P|LI)$/.test(el.tagName) ? text + "\n" : text;
    }
    return walk(node).replace(/\u00a0/g, " ").replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  }
  function authorLink(article, boundaries) {
    const anchors = ownElements(article, "a[href]", boundaries);
    return anchors.find((link) => {
      const url = linkUrl(link);
      if (!url || !/(^|\.)facebook\.com$/.test(url.hostname)) return false;
      const path = url.pathname;
      const profile = path === "/profile.php" || /^\/people\/[^/]+\/[^/]+/.test(path) || /\/user\/[^/]+/.test(path) || /^\/[^/]+\/?$/.test(path) && !/\.php$/.test(path);
      const reserved = /^\/(?:photo|watch|reel|share|login|help|stories|groups|hashtag|notifications|friends|home|marketplace)\/?$/;
      const text = readableText(link);
      return profile && !reserved.test(path) && text && !UI_TEXT.test(text);
    });
  }
  function timestamp(article, boundaries) {
    const exact = ownElements(article, "time[datetime], [data-utime]", boundaries)[0];
    if (exact) {
      const raw = exact.getAttribute("datetime") || Number(exact.getAttribute("data-utime")) * 1e3;
      const date = new Date(raw);
      if (!Number.isNaN(date.getTime())) return date.toISOString();
    }
    const link = commentLinks(article, boundaries)[0];
    if (link) {
      const titled = link.hasAttribute("title") ? link : link.querySelector("[title]");
      const title = titled?.getAttribute("title");
      if (title) return title.trim();
      const label = link.getAttribute("aria-label");
      if (label && !/^(?:like|mi piace|reply|rispondi|comment|commento)\b/i.test(label)) return label.trim();
      const text = (link.textContent || "").trim();
      if (text) return text;
    }
    const abbr = ownElements(article, "abbr[title], time", boundaries)[0];
    if (abbr) return abbr.getAttribute("title") || abbr.textContent.trim();
    const relative = ownElements(article, 'a, [role="link"]', boundaries).find((node) => /^\d+\s*(?:s|sec|min|m|h|d|g|w|wk|sett|y|a)(?:\b|$)/i.test(node.textContent.trim()));
    return relative?.getAttribute("title") || relative?.textContent.trim() || "";
  }
  function bodyText(article, author, boundaries) {
    const explicit = ownElements(article, '[data-ad-preview="message"], [data-testid="comment_message"]', boundaries);
    let candidates = explicit.length ? explicit : ownElements(article, '[dir="auto"], [dir="ltr"], [dir="rtl"]', boundaries);
    candidates = candidates.filter((node) => {
      if (node === author || node.contains(author) || node.closest('a, button, [role="button"]')) return false;
      if (node.querySelector(`${ARTICLE}, a[href*="comment_id="], time, abbr[data-utime]`)) return false;
      return true;
    });
    candidates = candidates.filter((node) => !candidates.some((other) => other !== node && other.contains(node)));
    const body = candidates.map(readableText).filter(Boolean).join("\n");
    if (body) return body;
    const media = ownElements(article, "img", boundaries).filter((img) => !img.closest("a") && !img.closest('button, [role="button"]'));
    return media.map((img) => `[Immagine: ${img.getAttribute("alt") || "senza descrizione"}]`).join("\n");
  }
  function includeRoot(root, selector) {
    return [...root.matches?.(selector) ? [root] : [], ...root.querySelectorAll(selector)];
  }
  function commentToken(link) {
    const url = linkUrl(link);
    return url && (url.searchParams.get("reply_comment_id") || url.searchParams.get("comment_id"));
  }
  function hidden(node) {
    for (let parent = node; parent; parent = parent.parentElement) {
      if (parent.hidden || parent.getAttribute("aria-hidden") === "true" || parent.style.display === "none") return true;
    }
    return false;
  }
  function commentContainers(root) {
    const candidates = new Set(includeRoot(root, `${ARTICLE}, ${ROOT_HINT}`).filter((node) => !hidden(node) && isCommentArticle(node)));
    for (const link of root.querySelectorAll('a[href*="comment_id="]')) {
      if (hidden(link) || !commentToken(link) || linkUrl(link)?.pathname === "/profile.php") continue;
      let covered = false;
      for (let parent = link.parentElement; parent; parent = parent.parentElement) {
        if (candidates.has(parent) && COMMENT_LABEL.test(parent.getAttribute("aria-label") || "") && authorLink(parent)) {
          covered = true;
          break;
        }
        if (parent === root) break;
      }
      if (covered) continue;
      let node = link.parentElement;
      for (let depth = 0; node && depth < 9 && (node === root || root.contains(node)); depth++, node = node.parentElement) {
        const tokens = new Set(commentLinks(node).map(commentToken).filter(Boolean));
        if (tokens.size > 1) break;
        const author = authorLink(node);
        if (tokens.size === 1 && author && bodyText(node, author)) {
          candidates.add(node);
          break;
        }
        if (node === root) break;
      }
    }
    const candidateLinks = new Map([...candidates].map((node) => [node, commentLinks(node)]));
    const byToken = /* @__PURE__ */ new Map();
    for (const [node, links] of candidateLinks) {
      const token = commentToken(links[0]);
      if (token) {
        if (!byToken.has(token)) byToken.set(token, []);
        byToken.get(token).push(node);
      }
    }
    const result = [...candidates].filter((node) => {
      const links = candidateLinks.get(node);
      if (!COMMENT_LABEL.test(node.getAttribute("aria-label") || "") && new Set(links.map(commentToken)).size > 1) return false;
      return !(byToken.get(commentToken(links[0])) || []).some((other) => {
        if (other === node) return false;
        if (node.contains(other) && !COMMENT_LABEL.test(node.getAttribute("aria-label") || "")) return true;
        return other.contains(node) && COMMENT_LABEL.test(other.getAttribute("aria-label") || "");
      });
    });
    return result.sort((a, b) => a.compareDocumentPosition(b) & 4 ? -1 : 1);
  }
  function extractComments(root, postUrl) {
    const rows = [];
    const containers = commentContainers(root);
    const boundaries = new Set(containers);
    const target = postUrl ? postIdentity(postUrl) : "";
    for (const article of containers) {
      if (isReply(article, boundaries)) continue;
      const links = commentLinks(article, boundaries);
      const linkedPost = links.map((link2) => postIdentity(linkUrl(link2).href)).filter(Boolean);
      if (target && linkedPost.length && !linkedPost.includes(target)) continue;
      const author = authorLink(article, boundaries);
      const username = author ? readableText(author) : "";
      if (!username) continue;
      const text = bodyText(article, author, boundaries);
      const time = timestamp(article, boundaries);
      const link = links[0];
      const id = link && linkUrl(link).searchParams.get("comment_id");
      rows.push({ key: id ? `id:${id}` : `fallback:${username}\0${text}\0${time}`, username, text, timestamp: time });
    }
    return rows;
  }
  function findPostScope(document2, postUrl) {
    const id = postIdentity(postUrl);
    const matchesPost = (node) => id && [...node.querySelectorAll("a[href]")].some((link) => {
      try {
        return postIdentity(new URL(link.getAttribute("href"), postUrl).href) === id;
      } catch {
        return false;
      }
    });
    const dialogs = [...document2.querySelectorAll('[role="dialog"]')].filter((el) => !el.hidden && el.getAttribute("aria-hidden") !== "true");
    const matchingDialog = dialogs.find(matchesPost);
    if (matchingDialog) return matchingDialog;
    const videoDialog = dialogs.find((node) => node.querySelector("video") && findCommentsOpener(node));
    if (videoDialog) return videoDialog;
    const commentDialogs = dialogs.filter((el) => [...el.querySelectorAll(ARTICLE)].some(isCommentArticle));
    if (commentDialogs.length === 1) return commentDialogs[0];
    const roots = commentContainers(document2);
    const targetRoots = roots.filter((node) => commentLinks(node).some((link) => postIdentity(linkUrl(link).href) === id));
    const panels = [...document2.querySelectorAll('aside, section, [role="complementary"], [role="region"]')].filter((panel2) => !panel2.hidden && panel2.getAttribute("aria-hidden") !== "true" && /^(?:comments|commenti)(?:\b|$)/i.test(panel2.getAttribute("aria-label") || ""));
    const panel = panels.find((node) => targetRoots.some((row) => node.contains(row))) || (panels.length === 1 && postIdentity(document2.URL) === id ? panels[0] : null);
    if (panel) return panel;
    const main = document2.querySelector('[role="main"], main');
    if (!main) {
      const external = targetRoots[0]?.closest('[role="dialog"], aside, [role="complementary"], section');
      if (external) return external;
      if (postIdentity(document2.URL) === id && document2.querySelector("video") && findCommentsOpener(document2.body)) return document2.body;
      return null;
    }
    const posts = [...main.querySelectorAll(ARTICLE)].filter((el) => !isCommentArticle(el) && !el.parentElement?.closest(ARTICLE));
    const matched = posts.find(matchesPost);
    if (matched) {
      if (targetRoots.some((row) => !matched.contains(row))) {
        const external = targetRoots.find((row) => !main.contains(row));
        return external?.closest('aside, section, [role="complementary"]') || (external ? external.parentElement : main);
      }
      return matched;
    }
    if (posts.length === 1) return posts[0];
    if (posts.length > 1) throw new Error("Sono presenti pi\xF9 post e non riesco a identificare quello richiesto. Apri il permalink del singolo post e riprova.");
    return main;
  }
  function isLoadMoreLabel(label) {
    const text = label.replace(/\s+/g, " ").trim();
    if (/rispost|repl|r[eé]pons/i.test(text)) return false;
    return /^(?:(?:visualizza|vedi|mostra|carica) (?:altri? |pi[uù] |i |\d+ )*(?:commenti)(?: precedenti)?|(?:view|see|load) (?:\d+ )?(?:more|previous) comments)$/i.test(text);
  }
  function findLoadMoreControl(root, visible = () => true) {
    const boundaries = new Set(commentContainers(root));
    return [...root.querySelectorAll('button, [role="button"], [role="link"], a[href]')].find((node) => {
      if (!visible(node) || ![node.getAttribute("aria-label"), node.textContent].filter(Boolean).some(isLoadMoreLabel)) return false;
      for (let parent = node.parentElement; parent; parent = parent.parentElement) {
        if (boundaries.has(parent)) return false;
        if (parent === root) break;
      }
      return true;
    }) || null;
  }
  function expandableCommentButtons(root) {
    const containers = commentContainers(root);
    const boundaries = new Set(containers);
    return [...root.querySelectorAll('button, [role="button"]')].filter((node) => {
      let article = node.parentElement;
      while (article && !boundaries.has(article)) article = article.parentElement;
      return article && !isReply(article, boundaries) && !!node.closest('[dir="auto"], [data-ad-preview="message"], [data-testid="comment_message"]') && /^(?:mostra altro|altro|see more|visualizza altro)$/i.test(node.textContent.trim());
    });
  }
  function layoutDiagnostics(document2, scope) {
    const candidates = commentContainers(scope || document2);
    return {
      schema: 1,
      pageKind: /\/watch\b/.test(document2.location.pathname) ? "watch" : /\/videos\//.test(document2.location.pathname) ? "video" : "post",
      roleArticles: document2.querySelectorAll(ARTICLE).length,
      commentPermalinks: document2.querySelectorAll('a[href*="comment_id="]').length,
      candidates: candidates.length,
      withAuthor: candidates.filter((node) => authorLink(node)).length,
      recognizedRows: extractComments(scope || document2).length,
      scope: scope ? { tag: scope.tagName, role: scope.getAttribute("role") || "" } : null,
      frames: document2.querySelectorAll("iframe").length,
      // Counts/structural flags only: no names, comments, URLs, cookies or HTML.
      samples: candidates.slice(0, 3).map((node) => ({
        tag: node.tagName,
        role: node.getAttribute("role") || "",
        hasCommentLabel: COMMENT_LABEL.test(node.getAttribute("aria-label") || ""),
        messageBlocks: ownElements(node, '[dir], [data-ad-preview="message"]').length,
        commentLinks: commentLinks(node).length
      }))
    };
  }

  // src/collector.js
  if (!globalThis.__facebookExcelCollector) {
    let scrollComments = function(scope) {
      const comments = commentContainers(scope);
      const last = comments[comments.length - 1];
      if (last) last.scrollIntoView({ block: "end", behavior: "instant" });
      let target = last?.parentElement || scope;
      while (target && target !== document.body) {
        if (target.scrollHeight > target.clientHeight + 30 && /auto|scroll/.test(getComputedStyle(target).overflowY)) {
          target.scrollTop = target.scrollHeight;
          return;
        }
        target = target.parentElement;
      }
      if (scope.matches('[role="main"], main') || !scope.closest('[role="dialog"]')) window.scrollBy(0, 650);
    };
    globalThis.__facebookExcelCollector = true;
    const documentToken = crypto.randomUUID();
    let running = false;
    let activeRunId;
    let stopRequested = false;
    const pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    const visible = (el) => !!el.getClientRects().length && getComputedStyle(el).visibility !== "hidden";
    async function send(message) {
      const reply = await chrome.runtime.sendMessage({ ...message, documentToken });
      if (!reply?.ok || reply.ignored) throw new Error(reply?.error || "Raccolta non pi\xF9 attiva in questa pagina.");
    }
    async function collect({ runId, url, initialRows = [], startedAt }) {
      running = true;
      activeRunId = runId;
      stopRequested = false;
      const rows = new Map(initialRows.map((row) => [row.key, row]));
      const dirty = /* @__PURE__ */ new Map();
      const started = startedAt || Date.now();
      let allSelected = false;
      let idle = 0;
      let passes = 0;
      let clickedOpener = false;
      let lastScope = null;
      let filterAttempts = 0;
      let lastFilterAttempt = 0;
      let phase = "preparing";
      let reason = "Nessun altro commento principale caricabile rilevato.";
      function capture(scope) {
        let changed = false;
        for (const row of extractComments(scope, url)) {
          const before = rows.get(row.key);
          if (!before || before.text !== row.text || before.timestamp !== row.timestamp) {
            dirty.set(row.key, row);
            changed = true;
          }
          rows.set(row.key, row);
        }
        return changed;
      }
      async function progress(message) {
        await send({ type: "PROGRESS", runId, updatedRows: [...dirty.values()], count: rows.size, allSelected, phase, message });
        dirty.clear();
      }
      try {
        await pause(1500);
        while (!stopRequested && Date.now() - started < 9e5) {
          if (!samePost(location.href, url)) throw new Error("La pagina non mostra pi\xF9 il post richiesto. Puoi scaricare i commenti gi\xE0 salvati.");
          let scope = findPostScope(document, url);
          lastScope = scope;
          if (!scope) {
            if (++passes > 12) throw new Error("Post non disponibile. Verifica accesso e apertura del pannello Comments.");
            await pause(1e3);
            continue;
          }
          if (!clickedOpener && !commentContainers(scope).length && !findSortControl(scope, visible)) {
            const opener = findCommentsOpener(scope, visible);
            if (opener) {
              clickedOpener = true;
              await progress("Apertura del pannello commenti del video\u2026");
              opener.click();
              await pause(1500);
              scope = findPostScope(document, url) || scope;
              lastScope = scope;
            }
          }
          let changed = capture(scope);
          const currentChoice = sortChoice(findSortControl(scope, visible));
          if (currentChoice === "all") allSelected = true;
          else if (currentChoice === "relevant" || currentChoice === "newest") {
            if (allSelected) filterAttempts = 0;
            allSelected = false;
          }
          phase = allSelected ? "reading" : "filter";
          await progress(allSelected ? "Lettura dei commenti principali\u2026" : "Verifica del filtro \xABTutti i commenti / All comments\xBB\u2026");
          if (!allSelected && filterAttempts < 3 && Date.now() - lastFilterAttempt > 2500) {
            filterAttempts++;
            lastFilterAttempt = Date.now();
            allSelected = await selectAllComments(
              () => findPostScope(document, url) || scope,
              { document, visible, pause, stopped: () => stopRequested }
            );
            scope = findPostScope(document, url) || scope;
            lastScope = scope;
            changed = capture(scope) || changed;
          }
          if (!allSelected) {
            phase = "filter";
            await progress("Seleziona \xABTutti i commenti / All comments\xBB dal menu Facebook. Riprender\xF2 automaticamente. Puoi anche fermare ed esportare i commenti gi\xE0 raccolti.");
            if (!rows.size && ++idle >= 24) break;
            if (rows.size) idle = 0;
            await pause(1200);
            continue;
          }
          phase = "reading";
          const more = findLoadMoreControl(scope, visible);
          const loading = controlBusy(more) || [...scope.querySelectorAll('[role="progressbar"], [aria-busy="true"]')].some(visible);
          await progress(loading ? "Facebook sta caricando il prossimo blocco di commenti\u2026" : more ? "Caricamento di altri commenti principali\u2026" : "Lettura dei commenti principali\u2026");
          for (const button of expandableCommentButtons(scope).filter(visible).slice(0, 5)) button.click();
          if (more && !loading) more.click();
          if (!loading) scrollComments(scope);
          idle = changed || loading ? 0 : idle + 1;
          if (idle >= 8) {
            if (more) reason = "Caricamento fermo: il pulsante per altri commenti non produce nuovi risultati.";
            break;
          }
          passes++;
          await pause(1200);
        }
        if (stopRequested) reason = "Raccolta interrotta manualmente: esportazione parziale.";
        else if (Date.now() - started >= 9e5) reason = "Raggiunto il limite di 15 minuti: esportazione potenzialmente parziale.";
        const finalScope = samePost(location.href, url) ? findPostScope(document, url) : null;
        if (finalScope) {
          capture(finalScope);
          const choice = sortChoice(findSortControl(finalScope, visible));
          if (choice === "relevant" || choice === "newest") allSelected = false;
        }
        if (!rows.size) throw new Error("Non riesco a leggere i commenti. Apri \xABComments\xBB e verifica \xABTutti i commenti\xBB. Se sono visibili, mostrami la diagnostica.");
        await send({ type: "COMPLETE", runId, rows: [...rows.values()], allSelected, reason });
      } catch (error) {
        let diagnostics;
        try {
          diagnostics = { ...layoutDiagnostics(document, lastScope), openerClicked: clickedOpener, phase, filterAttempts };
        } catch {
          diagnostics = { schema: 1, diagnosticError: true };
        }
        await send({ type: "FAILED", runId, error: error.message, rows: [...rows.values()], allSelected, diagnostics }).catch(() => {
        });
      } finally {
        running = false;
      }
    }
    chrome.runtime.onMessage.addListener((message, sender, reply) => {
      if (message.type === "COLLECTOR_STATUS") {
        reply({ ok: true, running, runId: activeRunId, documentToken });
      } else if (message.type === "COLLECT") {
        if (running) {
          reply({ ok: false, error: "Raccolta gi\xE0 in corso." });
          return;
        }
        void collect(message);
        reply({ ok: true, documentToken });
      } else if (message.type === "STOP_COLLECTING") {
        if (!running || message.runId !== activeRunId) {
          reply({ ok: false });
          return;
        }
        stopRequested = true;
        reply({ ok: true });
      }
    });
  }
})();
